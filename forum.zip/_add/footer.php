<footer>
    <div id="footer_central">
        <p>Forum test for VanHack.</p>
    </div>
</footer>